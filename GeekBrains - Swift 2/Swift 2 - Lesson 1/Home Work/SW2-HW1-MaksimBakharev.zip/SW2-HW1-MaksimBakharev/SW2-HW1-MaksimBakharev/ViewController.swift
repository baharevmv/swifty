//
//  ViewController.swift
//  SW2-HW1-MaksimBakharev
//
//  Created by max on 23.10.17.
//  Copyright © 2017 Maksim Bakharev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var userPasswordTextField: UITextField!
    @IBOutlet weak var outputTextField: UITextField!
    

    @IBAction func justAnotherGoButton(_ sender: UIButton) {
        if let login = userNameTextField.text {
            if let password = userPasswordTextField.text {
                if userNameTextField.text == "" {
                    outputTextField.text = "А где ваш логин?"
                    print("ERROR: Missing Login")
                } else if userPasswordTextField.text == ""{
                    outputTextField.text = "А где ваш пароль?"
                    print("ERROR: Missing Password")
                } else {
                    if password == "Password" {
                        outputTextField.text = "Добро пожаловать, \(login)!"
                    } else {
                        outputTextField.text = "Неверный пароль!"
                    }
                }
            }
        }
    }
}

