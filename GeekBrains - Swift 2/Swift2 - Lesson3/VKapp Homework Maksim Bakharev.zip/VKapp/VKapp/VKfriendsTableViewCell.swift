//
//  VKfriendsTableViewCell.swift
//  VKapp
//
//  Created by max on 31.10.17.
//  Copyright © 2017 Maksim Bakharev. All rights reserved.
//

import Foundation
