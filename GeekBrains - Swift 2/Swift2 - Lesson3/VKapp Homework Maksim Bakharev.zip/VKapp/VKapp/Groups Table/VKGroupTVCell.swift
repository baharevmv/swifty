//
//  VKGroupTVCell.swift
//  VKapp
//
//  Created by max on 31.10.17.
//  Copyright © 2017 Maksim Bakharev. All rights reserved.
//

import UIKit

class VKGroupTVCell: UITableViewCell {

    
    @IBOutlet weak var VKGroupName: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
