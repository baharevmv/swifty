//
//  VKFriendPhotoCVC.swift
//  VKapp
//
//  Created by max on 01.11.17.
//  Copyright © 2017 Maksim Bakharev. All rights reserved.
//

import UIKit

class VKFriendPhotoCVC: UICollectionViewCell {
    
}
