//
//  ViewController.swift
//  SW2-HW2-MaksimBakharev
//
//  Created by max on 23.10.17.
//  Copyright © 2017 Maksim Bakharev. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var userNameTextField: UITextField!
    @IBOutlet weak var userPasswordTextField: UITextField!

    override func shouldPerformSegue(withIdentifier identifier: String, sender: Any?) -> Bool {
        // Checking User Data
        let checkResult = checkUserData()
        // Alert Message
        if !checkResult {
            showLoginError()
        }
        return checkResult
        }
    
    func checkUserData() -> Bool{
        let login = userNameTextField.text
        let password = userPasswordTextField.text
        
        if login == "admin" && password == "123" {
            return true
        } else {
            return false
        }
    }
    
    func showLoginError() {
        // Making alert controller
        let alter = UIAlertController(title: "Ошибка", message: "Введены неверные данные пользователя", preferredStyle: .alert)
        //making UIAlertControllerButton
        let action = UIAlertAction(title: "OK", style: .cancel, handler: nil)
        //Adding another button
        alter.addAction(action)
        //Showing Alert Controller
        present(alter, animated:true, completion: nil)
        
    }
    
    
}

